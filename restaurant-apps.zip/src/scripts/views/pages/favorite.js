/* eslint-disable func-names */
import FavoriteRestaurant from '../../data/favoriterestaurant-idb';
import { createRestaurantItemTemplate, createRestaurantNotFoundTemplate } from '../templates/template-creator';

const Favorite = {
  async render() {
    return `
    
    <div class="restaurant-not-found" id="restaurant-not-found"></div>
      <section class="content">
      <div id="favorite" class="explore favorite">
          <h1 tabindex="0" class="explore__label">Favorite Restaurant</h1>
          <div id="loadingFavorite" class="lds-dual-ring"></div>          
          <h2 id="empty-favorite" class="empty-favorite">Tambahkan restaurant favorite anda</h2>
          <div id="posts" class="posts-container favorites-container"></div>
      </div>
  </section>

      `;
  },

  async afterRender() {
    const loaderFavorite = document.querySelector('#loadingFavorite');
    window.onload = function () {
      loaderFavorite.style.display = 'none';
    };
    try {
      const restaurants = await FavoriteRestaurant.getAllRestaurants();
      const restaurantsContainer = document.querySelector('#posts');
      const emptyFavorite = document.querySelector('#empty-favorite');
      window.onload();
      if (restaurants.length !== 0) {
        emptyFavorite.style.display = 'none';
      }
      restaurants.forEach((resto) => {
        restaurantsContainer.innerHTML += createRestaurantItemTemplate(resto);
      });
      this.shortenText();
    } catch (error) {
      window.onload();
      const restaurantNotFound = document.querySelector('#restaurant-not-found');
      const favoriteContainer = document.querySelector('#favorite');
      restaurantNotFound.style.display = 'block';
      let errorMessage;
      if (error.message === 'Failed to fetch') {
        errorMessage = 'Please, check your internet connection';
      } else {
        errorMessage = 'Sorry, something wrong happened';
      }
      favoriteContainer.style.display = 'none';
      restaurantNotFound.innerHTML = createRestaurantNotFoundTemplate(errorMessage);
    }
  },
  async shortenText() {
    const limitCharacter = 290;
    const contents = document.querySelectorAll('.post-item__description');
    contents.forEach((content) => {
      if (content.textContent.length < limitCharacter) {
        content.nextElementSibling.style.display = 'none';
      } else {
        const displayText = content.textContent.slice(0, limitCharacter);
        content.innerHTML = `${displayText}<span>...</span>`;
      }
    });
  },
};

export default Favorite;
