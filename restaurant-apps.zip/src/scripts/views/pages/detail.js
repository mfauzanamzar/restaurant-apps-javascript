/* eslint-disable func-names */
/* eslint-disable no-plusplus */
import RestaurantSource from '../../data/restaurant-source';
import UrlParser from '../../routes/url-parser';
import { createRestaurantDetailTemplate, createRestaurantNotFoundTemplate } from '../templates/template-creator';
import LikeButtonInitiator from '../../utils/like-button-initiator';

const Detail = {
  async render() {
    return `
      <div class="restaurant-not-found" id="restaurant-not-found"></div>            
      <div id="loadingDetail" class="lds-dual-ring"></div>
      <div id="restaurant" class="restaurant"></div>
      <div id="likeButtonContainer"></div>
      `;
  },

  async afterRender() {
    const loaderDetail = document.querySelector('#loadingDetail');
    window.onload = function () {
      loaderDetail.style.display = 'none';
    };
    try {
      const banner = document.querySelector('hero-banner');
      banner.style.display = 'none';
      const url = UrlParser.parseActiveUrlWithoutCombiner();
      const resto = await RestaurantSource.detailRestaurant(url.id);
      const restaurantsContainer = document.querySelector('#restaurant');
      window.onload();
      restaurantsContainer.innerHTML = createRestaurantDetailTemplate(resto.restaurant);
      const stars = document.querySelector('#stars');
      const numberOfStars = resto.restaurant.rating;
      for (let i = 1; i <= numberOfStars; i++) {
        const star = '⭐️';
        stars.innerHTML += star;
      }
      this._addConsumerReview(url);
      LikeButtonInitiator.init({
        likeButtonContainer: document.querySelector('#likeButtonContainer'),
        restaurant: {
          id: resto.restaurant.id,
          name: resto.restaurant.name,
          city: resto.restaurant.city,
          description: resto.restaurant.description,
          pictureId: resto.restaurant.pictureId,
          rating: resto.restaurant.rating,
        },
      });
    } catch (error) {
      window.onload();
      const restaurantNotFound = document.querySelector('#restaurant-not-found');
      restaurantNotFound.style.display = 'block';
      let errorMessage;
      if (error.message === 'Failed to fetch') {
        errorMessage = 'Please, check your internet connection';
      } else {
        errorMessage = 'Sorry, something wrong happened';
      }
      restaurantNotFound.innerHTML = createRestaurantNotFoundTemplate(errorMessage);
    }
  },

  async _addConsumerReview(url) {
    const submit = document.querySelector('#submit');
    submit.addEventListener('click', async () => {
      const inputName = document.querySelector('#name').value;
      const inputReview = document.querySelector('#review').value;
      const review = {
        id: url.id,
        name: inputName,
        review: inputReview,
      };
      await RestaurantSource.postReviews(review);

      this.afterRender();
    });
  },
};

export default Detail;
